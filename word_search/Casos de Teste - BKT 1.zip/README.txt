Arquivo zip gerado em: 23/09/2022 19:36:14 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: BKT 1