Arquivo zip gerado em: 26/09/2022 10:56:01 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: D&C 2